<?php
include('header.php');
?>

<?php
	if(isset($_POST['bookBtn'])){
		$getLastBookIdQry='select id from booktbl order by id desc';
		
		$bookDrQry='update booktbl set drId='. $_POST['bookBtn'] .' where id = '. mysqli_fetch_array(mysqli_query($connect, $getLastBookIdQry))['id'];
		if(mysqli_query($connect, $bookDrQry)){
			echo '<script>alert("driver booked successfully");</script>';
		}else{
			echo '<script>alert("driver booking failed");</script>';
		}
	}
?>

<form action='<?php $_PHP_SELF ?>' method='post' >
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
		<div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Bordered Table</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tr>
                  <th style="width: 10px">#</th>
				  <th style="width: 25%">Picture</th>
                  <th style="width: 25%">Name</th>
				  <th style="width: 50px">status</th>
                  <th style="width: 25%">Rating</th>
                  <th style="width: 10%">Rating in digit</th>
					<?php
						if(isset($_SESSION['userClId'])){
							echo '<th style="width: 50px">book</th>';
						}
					?>
                </tr>
				<?php
					$getDrQry='select * from drivertbl';
					$getDrRslt=mysqli_query($connect, $getDrQry);
					if(mysqli_num_rows($getDrRslt)){
						$anyDrPresent=0;
						while($getDrRow=mysqli_fetch_array($getDrRslt)){
							if(!($getDrRow['carType']=='' && $getDrRow['carNum']=='' && $getDrRow['drLicence'] == '')){
								$anyDrPresent=1;
								echo '<tr>
											<td>'. $getDrRow['id'] .'</td>
											<td>
										  
											<div class="pull-left image">
												<img src="profilePic/driver/'. $getDrRow['id'] .'.jpg"  style="height:100px;width:100px;" class="img-circle" alt="User Image">
											</div>
								
								
											</td>
											<td>'. $getDrRow['name'] .'</td>';
								if($getDrRow['carType']=='' && $getDrRow['carNum']=='' && $getDrRow['drLicence'] != ''){
									echo '<td>driver</dr>';
								}else if(!($getDrRow['carType']=='' && $getDrRow['carNum']=='') && $getDrRow['drLicence'] == ''){
									echo '<td>car lender</dr>';
								}else{
									echo '<td>driver cum car lender</dr>';
								}		
								echo '<td>
											<div class="progress progress-xs">
												<div class="progress-bar progress-bar-danger" style="width: 55%"></div>
											</div>
											</td>
											<td><span class="badge bg-red">55%</span></td>';
								if(isset($_SESSION['userClId'])){
									
									echo'<td><span >
											<button name="bookBtn" value="'. $getDrRow['id'] .'" >
												book
											</button>
											</span></td>';
								}
								echo '</tr>';
								
							}
						}
						if($anyDrPresent==0){
							echo '<tr><td></td><td></td><td>
								No driver available
								</td><td></td><td></td><td></td></tr>';
						}
					}
					
					else{
						echo '<tr><td></td><td></td><td>
						No driver available
						</td><td></td><td></td><td></td></tr>';
					}
				?>
               
              </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">&laquo;</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">&raquo;</a></li>
              </ul>
            </div>
          </div>
  </div>
  </form>
  
  <?php
include('footer.php');
  ?>