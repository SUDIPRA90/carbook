<html>

<?php
session_start();
include('connectionStr.php');
/*$qry1='delete from drivertbl';
$rslt=mysqli_query($connect, $qry1);
$qry2='delete from clienttbl';
$rslt=mysqli_query($connect, $qry2);
unset($_SESSION['userClId']);
unset($_SESSION['userDrId']);*/


?>

<body>
<?php
	if(file_exists('profilePic/driver/14.jpg')){
		echo '<h1>exist</h1>';
	}else{
		echo '<h1>not exist</h1>';
	}
?>
</body>
</html>