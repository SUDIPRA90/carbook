<?php
include('header.php');
?>


<div class="content-wrapper">
<form action='<?php $PHP_SELF ?>' method='post' >
    <!-- Content Header (Page header) -->
		<div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Bordered Table</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered" style=''>
                <tr>
                  <!--<th style="width: 10px">#</th>-->
                  <th style="">Id</th>
                  <th style=" ">Distance in meter</th>
                  <th style=" ">Fare in rupee</th>
				  
                </tr>
				<?php
					$getFaresQry='select * from faretbl';
					$getFaresRslt=mysqli_query($connect, $getFaresQry);
					if(mysqli_num_rows($getFaresRslt)){
						while ($getFaresRow=mysqli_fetch_array($getFaresRslt)){
							echo '<tr>
									<td>'. $getFaresRow['id'] .'</td>
									<td>'. $getFaresRow['meter'] .'</td>
									<td>'. $getFaresRow['rate'] .'</td>		
								</tr>';
						}
					}else{
						echo '<tr><td><td >No fare is available</td><td></td></tr>';
					}
				?>
                
              </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">&laquo;</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">&raquo;</a></li>
              </ul>
            </div>
          </div>
		  </form>
  </div>
  
  <?php
include('footer.php');
  ?>