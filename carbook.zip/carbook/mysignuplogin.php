<?php
	session_start();
	include('connectionStr.php');
?>

<html>
<head>
<script src='jquery-3.4.1.js' >
</script>
<style>
#showDriverLoginBtn{
	padding:10px;
	margin-bottom:200px;
}
#clLogSignDiv{
	height:500px;
	width:100%;
}
#clLoginDiv{
	height:500px;
	width:50%;
	float:left;
}
#clSignupDiv{
	height:500px;
	width:50%;
	float:left;
}
#drLogSignDiv{
	height:500px;
	width:100%;
	display:none;
}
#drLoginDiv{
	height:500px;
	width:50%;
	float:left;
}
#drSignupDiv{
	height:500px;
	width:50%;
	float:left;
}
</style>
</head>

<body>
	<?php
		if(isset($_SESSION['userClId'])){
			echo '<script>window.location.href="dashboard.php";</script>';
		}
		if(isset($_SESSION['userDrId'])){
			echo '<script>window.location.href="drDashboard.php";</script>';
		}
		if(isset($_POST['clSignupBtn'])){
			$signClQry='insert into clienttbl (phNo, pass) values ("'. $_POST['clSignupPhNo'] .'", "'.  $_POST['clSignupPass'] .'")';
			if(mysqli_query($connect, $signClQry)){
				echo '<script>alert("successfully signed up");</script>';
				$loginQry='select * from clienttbl where phNo = "'. $_POST['clLoginPhNo'] .'" and pass = "'.  $_POST['clLoginPass'] .'"';
				$loginRslt=mysqli_query($connect, $loginQry);
				$_SESSION['userClId']=mysqli_fetch_array($loginRslt)['id'];
				echo '<script>window.location.href="dashboard.php";</script>';
			}else{
				echo '<script>alert("error occured");</script>';
			}
		}
		if(isset($_POST['clLoginBtn'])){
			$loginQry='select * from clienttbl where phNo = "'. $_POST['clLoginPhNo'] .'" and pass = "'.  $_POST['clLoginPass'] .'"';
			$loginRslt=mysqli_query($connect, $loginQry);
			if($loginRslt){
				if(mysqli_num_rows($loginRslt)){
					$_SESSION['userClId']=mysqli_fetch_array($loginRslt)['id'];
					echo '<script>window.location.href="dashboard.php";</script>';
				}
				else{
					echo '<script>alert("wrong username or password");</script>';
				}
			}
			else{
				echo '<script>alert("error");</script>';
			}
		}
		
		if(isset($_POST['drSignupBtn'])){
			$signDrQry='insert into drienttbl (phNo, pass) values ("'. $_POST['drSignupPhNo'] .'", "'.  $_POST['drSignupPass'] .'")';
			if(mysqli_query($connect, $signDrQry)){
				echo '<script>alert("successfully signed up");</script>';
				$loginQry='select * from drienttbl where phNo = "'. $_POST['drLoginPhNo'] .'" and pass = "'.  $_POST['drLoginPass'] .'"';
				$loginRslt=mysqli_query($connect, $loginQry);
				$_SESSION['userDrId']=mysqli_fetch_array($loginRslt)['id'];
				echo '<script>window.location.href="drDashboard.php";</script>';
			}else{
				echo '<script>alert("error occured");</script>';
			}
		}
		if(isset($_POST['drLoginBtn'])){
			$loginQry='select * from drienttbl where phNo = "'. $_POST['drLoginPhNo'] .'" and pass = "'.  $_POST['drLoginPass'] .'"';
			$loginRslt=mysqli_query($connect, $loginQry);
			if($loginRslt){
				if(mysqli_num_rows($loginRslt)){
					$_SESSION['userDrId']=mysqli_fetch_array($loginRslt)['id'];
					echo '<script>window.location.href="drDashboard.php";</script>';
				}
				else{
					echo '<script>alert("wrong username or password");</script>';
				}
			}
			else{
				echo '<script>alert("error");</script>';
			}
		}
	?>

	<button id='showDriverLoginBtn' >login or signup insteed</button>
	<form action='<?php $_PHP_SELF ?>' method='post'>
		<div id='clLogSignDiv'>
			<p>signup or login as client</p>
			<div id='clLoginDiv'>
				<input placeholder='email' id='clLoginPhNo' name='clLoginPhNo' />
				<input placeholder='password' id='clLoginPass' name='clLoginPass'  />
				<button id='clLoginBtn' name='clLoginBtn'  >login</button>
			</div>
			<div id='clSignupDiv'>
				<input placeholder='email' id='clSignupPhNo' name='clSignupPhNo'  />
				<input placeholder='password' id='clSignupPass' name='clSignupPass'  />
				<button id='clSignupBtn' name='clSignupBtn'  >Signup</button>
			</div>
		</div>
		<div id='drLogSignDiv'>
			<p>signup or login as driver</p>
			<div id='drLoginDiv'>
				<input placeholder='email' id='drLoginPhNo'  name='drLoginPhNo' />
				<input placeholder='password' id='drLoginPass' name='drLoginPass'  />
				<button id='drLoginBtn' name='drLoginBtn' >login</button>
			</div>
			<div id='drSignupDiv'>
				<input placeholder='email' id='drSignupPhNo' name='drSignupPhNo'  />
				<input placeholder='password' id='drSignupPass' name='drSignupPass'  />
				<input type='file' id='drPic' name='drPic'  />
				<button id='drSignupBtn' name='drSignupBtn'  >Signup</button>
			</div>
		</div>
	</form>
	
	<script>
		$(document).ready(function(){
			
			var cntDisplayDrOrCl=1;
			$('#showDriverLoginBtn').click(function(){
				if(cntDisplayDrOrCl==1){
					$('#clLogSignDiv').css('display','none');
					$('#drLogSignDiv').css('display','block');
					cntDisplayDrOrCl=2;
				}else{
					$('#clLogSignDiv').css('display','block');
					$('#drLogSignDiv').css('display','none');
					cntDisplayDrOrCl=1;
				}
			});
			
			$('#clLoginBtn').click(function(){
				if(!$('#clLoginPhNo').val()){
					alert('client phno required');
					return false;
				}
				if(!$('#clLoginPass').val()){
					alert('client pass required');
					return false;
				}
			});
			$('#clSignupBtn').click(function(){
				if(!$('#clSignupPhNo').val()){
					alert('client phno required');
					return false;
				}
				if(!$('#clSignupPass').val()){
					alert('client pass required');
					return false;
				}
			});
			$('#drLoginBtn').click(function(){
				if(!$('#drLoginPhNo').val()){
					alert('driver phno required');
					return false;
				}
				if(!$('#drLoginPass').val()){
					alert('driver pass required');
					return false;
				}
			});
			$('#drSignupBtn').click(function(){
				if(!$('#drSignupPhNo').val()){
					alert('driver phno required');
					return false;
				}
				if(!$('#drSignupPass').val()){
					alert('driver pass required');
					return false;
				}
			});
		});
	</script>
</body>
<html>