<?php
include('header.php');
?>
<style>
#carDtlsDiv{
	height:300px;
	width:80%;
	border: 1px solid blue;
	display:none;
}
</style>
<?php
	if(isset($_POST['changeProfBtn'])){
		if(file_exists($_FILES['changePic']['tmp_name'])){
			$fileName=$_FILES['changePic']['name'];
			$fileTempName=$_FILES['changePic']['tmp_name'];
			$fileStore='profilePic/driver/'.  $_SESSION['userDrId'] . '.jpg';
			move_uploaded_file($fileTempName, $fileStore);
		}
		$updateProfInfoQry='update drivertbl set name="'. $_POST['name'] .'", 
		email="'. $_POST['email'] .'", phNo="'. $_POST['phNo'] .'", drLicence="'. $_POST['drLicence'] .'",
		carType="'.  $_POST['carType'] .'", carNum="'. $_POST['carNum'] .'"';
		if(mysqli_query($connect, $updateProfInfoQry)){
			echo '<script>alert("profile updated successfully");</script>';
		}
		else{
			echo '<script>alert("error occured while updating profile");</script>';
		}
	}
	
	$getProfInfoQry='select * from drivertbl where id='. $_SESSION['userDrId'];
	$getProfInfoRow=mysqli_fetch_array(mysqli_query($connect, $getProfInfoQry));
	$name=$getProfInfoRow['name'];
	$email=$getProfInfoRow['email'];
	$phNo=$getProfInfoRow['phNo'];
	$drLicence=$getProfInfoRow['drLicence'];
	$carType=$getProfInfoRow['carType'];
	$carNum=$getProfInfoRow['carNum'];
?>

<div class="content-wrapper">
<center>
<div style='width:60%;'>
    <!-- Content Header (Page header) -->
    <div class="box box-primary">
		
            <div class="box-header with-border">
              <h3 class="box-title">My profile</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form action='<?php $_PHP_SELF ?>' method='post'  enctype='multipart/form-data'>
			
              <div class="box-body">
				<div style='height:200px;width:90%;'>
				<?php
					if(file_exists('profilePic/driver/'. $_SESSION['userDrId'] .'.jpg')){
						echo '<img src="profilePic/driver/'. $_SESSION['userDrId'] .'.jpg"
						 style="height:200px;width200px;" class="img-circle" alt="Profile pic">';
					}else{
						
					}
				?>
					
				</div>
				 <div class="form-group">
                  <label for="exampleInputFile">change pic</label>
                  <input type="file" id="changePic" name='changePic'>
                </div>
				<div class="form-group" >
                  <label for="exampleInputEmail1">Name</label>
                  <input type="text" class="form-control" id='name' name='name' value='<?php echo $name ?>' placeholder="Name">
                </div>
				
                <div class="form-group" >
                  <label for="exampleInputEmail1">Email address</label>
                  <input type="email" class="form-control" id="email" name='email' value='<?php echo $email ?>' placeholder="Enter email">
                </div>
                <div class="form-group">
                  <label for="exampleInputPassword1">Phone no</label>
                  <input type="text" class="form-control" id="phNo" name='phNo' value='<?php echo $phNo ?>' placeholder="Phone no">
                </div>
				<div class="form-group">
                  <label for="exampleInputPassword1">Driving Licence</label>
                  <input type="text" class="form-control" id="drLicence" name='drLicence' value='<?php echo $drLicence ?>' placeholder="Driving licence">
                </div>
				<div class="form-group">
                  <label for="exampleInputPassword1">Do you have your own car?</label>
				  <p><input type="radio" id='ownCarYes' name="ownCar" value="1" <?php if(!($carType == '' && $carNum == ''))echo 'checked'; ?>> Yes<br>
				  <input type="radio" id='ownCarNo' name="ownCar" value="2" <?php if($carType == '' && $carNum == '')echo 'checked'; ?>> No<br></p>
                </div>
               <div id='carDtlsDiv'>
				<div class="form-group">
                  <label for="exampleInputPassword1">car type</label>
                  <input type="text" class="form-control" id="carType" name='carType' value='<?php echo $carType ?>' placeholder="Driving licence">
                </div>
				<div class="form-group">
                  <label for="exampleInputPassword1">car number</label>
                  <input type="text" class="form-control" id="carNum" name='carNum' value='<?php echo $carNum ?>' placeholder="Driving licence">
                </div>
			   </div>
                <!--<div class="checkbox">
                  <label>
                    <input type="checkbox"> Check me out
                  </label>
                </div>-->
              </div>
              <!-- /.box-body -->

              <div class="box-footer">
                <button id='changeProfBtn' name='changeProfBtn' type="submit" class="btn btn-primary">Submit</button>
              </div>
            </form>
          </div>
    <!-- /.content -->
	  </div>
  </center>
  </div>
  <script>
$(document).ready(function (){
	if($('#ownCarYes').prop("checked")){
		$('#carDtlsDiv').css('display', 'block');
	}
	$('#ownCarYes').change(function(){
		$('#carDtlsDiv').css('display', 'block');
	});
	$('#ownCarNo').change(function(){
		$('#carNum').val('');
		$('#carType').val('');
		$('#carDtlsDiv').css('display', 'none');
	});
});
</script>
  <?php
include('footer.php');
  ?>