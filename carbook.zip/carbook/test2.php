<html>
<?php
	//if(isset($_POST['file1'])){
	if(file_exists($_FILES['file1']['tmp_name'])){
		echo '<script>alert("set");</script>';
	}else{
		echo '<script>alert("not set");</script>';	
	}
?>
<body>
	<form action='<?php $_PHP_SELF ?>' method='post'  enctype='multipart/form-data'>
		<input type='file' name='file1' />
		<input type='submit' />
	</form>
</body>
</html>