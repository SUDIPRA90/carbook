<html>
<head>
<script src='jquery-3.4.1.js'>
</script>
<head>
<body>
<script>
$(document).ready(function(){
	window.location.href='pages/examples/login.php';
});
</script>
</body>
</html>