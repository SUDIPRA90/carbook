<?php
session_start();
if(isset($_SESSION['userClId'])){
	echo '<script>window.location.href="clPayments.php";</script>';
}
else if(isset($_SESSION['userDrId'])){
	echo '<script>window.location.href="drPayments.php";</script>';
}else{
	echo '<script>window.location.href="index.php";</script>';
}
?>