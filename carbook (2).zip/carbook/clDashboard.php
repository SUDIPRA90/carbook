<?php
include('header.php');
?>


<style>
.bookingInfoCl{height:100px;width:20%;text-align:center;float:left;padding-top:20px;}
#map{height:800px;width:100%;border: 1px solid blue}
#bookBtnDiv, #calDistBtnDiv{margin-top:20px; padding-left:20px;padding-right:20px; margin-top:20px; height:40px;width:200px; float:left;display:none;}
#whichLocTxt{background-color:red; color:white;}
#distTxtDiv{float:left; padding-left:20px;padding-right:20px;padding-top:20px}
#bookDatediv{float:left; padding-left:20px;padding-right:20px;padding-top:20px}

@media only screen and (max-width: 768px){
	.bookingInfoCl, #distTxtDiv, #bookDatediv{height:50px;width:100%;text-align:center;}
	#distTxtDiv{ padding-left:25px;padding-right:25px;padding-top:20px}
	#bookDatediv{ padding-left:25px;padding-right:25px;padding-top:4px}
}
</style>

<?php
	if(isset($_POST['bookBtn'])){
		$getFaresQry='select * from faretbl where meter < '. $_POST['distTxt'] * 1000 .' order by meter desc';
		$getFaresRslt=mysqli_query($connect, $getFaresQry);
		if(mysqli_num_rows($getFaresRslt)){
			$amount=$_POST['distTxt'] * mysqli_fetch_array($getFaresRslt)['rate'] * 1000;
		}else{
			$amount=0;
		}
		$bookQry='insert into booktbl (clId, fromLoc, toLoc, fromLatLng, toLatLng, dateTime, distance, amount, status) values('. $_SESSION['userClId'] .', "'. $_POST['fromLocTxt'] .'", "'. $_POST['toLocTxt'] .'", 
			"'. $_POST['fromLocHid'] .'", "'. $_POST['toLocHid'] .'", "'. date_format(date_create($_POST['bookDate']), 'Y-m-d'). " 00:00:00" .'", '. $_POST['distTxt'] .', '. $amount .', 1)';
		if(mysqli_query($connect, $bookQry)){
			echo '<script>alert("booking successfull");</script>';
			echo '<script>window.location.href="driver.php";</script>';
		}else{
			echo '<script>alert("error while booking");</script>';
		}
		//echo '<script>$("#bookBtn").css("display", "none");</script>';
	
	}
?>



<div class="content-wrapper">
	
	<form action='<?php $_PHP_SELF ?>' method='post' >
		<!--<h3 id='whichLocTxt'>please enter the location you want to start your journey from</h3>-->
		<div class='bookingInfoCl'><input type ='text' id='fromLocTxt' name='fromLocTxt' placeholder='journey start place' style='width:90%;padding:10px;' ></div>
		<div class='bookingInfoCl'><input type ='text' id='toLocTxt' name='toLocTxt' placeholder='destination'style='width:90%;padding:10px;' ></div>
		<div id='distTxtDiv' ><input  type='text' id='distTxt' name='distTxt' placeholder='distance' style='width:100%;' readonly /></div>
		<div id='bookDatediv' ><input type='date' id='bookDate' name='bookDate' style='width:100%;' /></div>
		<div id='calDistBtnDiv' ><button id='calDistBtn' name='calDistBtn' style='background-color:green;color:white;'>distance</button></div>
		<div id='bookBtnDiv' ><button name='bookBtn' id='bookBtn' style='background-color:green; color:white;' >book now</button> </div>
		<div id='map'></div>
		<input type ='text' id='fromLocHid' name='fromLocHid' style='display:none'/>
		<input type ='text' id='toLocHid' name='toLocHid' style='display:none' />
	</form>
	
</div>
  
<script>

	$(document).ready(function(){
		$('#calDistBtn').click(function(){
			calculateDistance();
			$('#calDistBtnDiv').css('display', 'none');
			$('#bookBtnDiv').css('display', 'block');
			return false;
		});
	});
	
	
	var loc={lat: 23.07846539287924, lng: 88.52151381717499};
	var whichLocCount=1;
	var marker;
	var map;
	var input =  document.getElementById('fromLocTxt');
	function initMap(){
		
		map=new google.maps.Map(document.getElementById('map'), {
			zoom: 16,
			center: loc
		});
		
		marker = new google.maps.Marker({
			map: map,
			position: loc
        });
		
		
		var service;
		map.addListener('click', function(args) {
			map.setCenter(args.latLng);
			if(whichLocCount==1){
				getPlaceNameByGeoCoder(args.latLng);
				$('#fromLocHid').val(args.latLng);
				//alert(args.lat());
			}else{
				getPlaceNameByGeoCoder(args.latLng);
				$('#toLocHid').val(args.latLng);
				$('#calDistBtnDiv').css('display', 'block');
			}
		});
		
		autoCmpltTxtPlace( document.getElementById('fromLocTxt'));
		autoCmpltTxtPlace( document.getElementById('toLocTxt'));
	}
	
	function getPlaceNameByGeoCoder(ll){
		var geocoder = new google.maps.Geocoder();
		//var latlng = new google.maps.LatLng(ll.lat(), ll.lng());
		geocoder.geocode({'latLng': ll}, function (results, status) {
			if (status ==google.maps.GeocoderStatus.OK) {
				if (results[0]) {
					marker.setPosition(ll);
					//alert(results[1].formatted_address);
					if(whichLocCount==1){
						whichLocCount=2;
						$('#fromLocTxt').val(results[1].formatted_address);
					}
					else{
						whichLocCount=1;
						$('#toLocTxt').val(results[1].formatted_address);
					}
				} else {
					alert( 'No results found');
				}
			} else {
				alert( 'Geocoder failed due to: ' + status);
			}
		});
	}
	
	function autoCmpltTxtPlace(input){
		var autocomplete = new google.maps.places.Autocomplete(input);
        autocomplete.bindTo('bounds', map);
		var infowindow = new google.maps.InfoWindow();
		
		autocomplete.addListener('place_changed', function() {
			infowindow.close();
			//marker.setVisible(false);
			var place = autocomplete.getPlace();

			if (!place.geometry) {
				// User entered the name of a Place that was not suggested and
				// pressed the Enter key, or the Place Details request failed.
				window.alert("No details available for input: '" + place.name + "'");
				return;
			}else{
				if(whichLocCount==1){
					whichLocCount=2;
					('#fromLocHid').val(args.latLng);
				}
				else{
					whichLocCount=1;
					$('#calDistBtnDiv').css('display', 'block');
					('#toLocHid').val(args.latLng);
				}
			}

			// If the place has a geometry, then present it on a map.
			if (place.geometry.viewport) {
				map.fitBounds(place.geometry.viewport);
			} else {
				map.setCenter(place.geometry.location);
				//map.setZoom(17);
			}
			/*marker.setIcon(({
				url: place.icon,
				size: new google.maps.Size(71, 71),
				origin: new google.maps.Point(0, 0),
				anchor: new google.maps.Point(17, 34),
				scaledSize: new google.maps.Size(35, 35)
			}));*/
			marker.setPosition(place.geometry.location);
			marker.setVisible(true);
			var item_Lat =place.geometry.location.lat()
			var item_Lng= place.geometry.location.lng()
			var item_Location = place.formatted_address;
			//alert("Lat= "+item_Lat+"_____Lang="+item_Lng+"_____Location="+item_Location);
			$("#lat").val(item_Lat);
			$("#lng").val(item_Lng);
			$("#location").val(item_Location);
			var address = '';
			if (place.address_components) {
				address = [
				  (place.address_components[0] && place.address_components[0].short_name || ''),
				  (place.address_components[1] && place.address_components[1].short_name || ''),
				  (place.address_components[2] && place.address_components[2].short_name || '')
				].join(' ');
			}

			infowindow.setContent('<div><strong>' + place.name + '</strong><br>' + address);
			infowindow.open(map, marker);
        });
	}
	
	function calculateDistance() {
		var origin = $('#fromLocTxt').val();
		var destination = $('#toLocTxt').val();
		var service = new google.maps.DistanceMatrixService();
		service.getDistanceMatrix(
		{
			origins: [origin],
			destinations: [destination],
			travelMode: google.maps.TravelMode.DRIVING,
			unitSystem: google.maps.UnitSystem.IMPERIAL, // miles and feet.
			// unitSystem: google.maps.UnitSystem.metric, // kilometers and meters.
			avoidHighways: false,
			avoidTolls: false
		}, callback);
	}
	// get distance results
	function callback(response, status) {
		//alert('');
		if (status != google.maps.DistanceMatrixStatus.OK) {
			//$('#result').html(err);
			alert(err);
		} else {
			var origin = response.originAddresses[0];
			var destination = response.destinationAddresses[0];
			if (response.rows[0].elements[0].status === "ZERO_RESULTS") {
				//$('#result').html("Better get on a plane. There are no roads between "  + origin + " and " + destination);
				alert('no road');
			} else {
				var distance = response.rows[0].elements[0].distance;
				var duration = response.rows[0].elements[0].duration;
				console.log(response.rows[0].elements[0].distance);
				var distance_in_kilo = distance.value / 1000; // the kilom
				var distance_in_mile = distance.value / 1609.34; // the mile
				var duration_text = duration.text;
				var duration_value = duration.value;
				/*$('#in_mile').text(distance_in_mile.toFixed(2));
				$('#in_kilo').text(distance_in_kilo.toFixed(2));
				$('#duration_text').text(duration_text);
				$('#duration_value').text(duration_value);
				$('#from').text(origin);
				$('#to').text(destination);*/
				$('#distTxt').val(distance_in_kilo.toFixed(2));
			}
		}
	}
	
</script>

<script async defer src='https://maps.googleapis.com/maps/api/js?key=AIzaSyA713ezzBkS6YSMDWqK9N6CqopC0OK57zA&callback=initMap&libraries=places'></script>'


  <?php
include('footer.php');
  ?>