<?php
include('header.php');
?>
<style>
#rateDiv{
	height:1px;width:1px;border: 1px solid blue;
	position:static;top:2px;
}
#rateContentDiv{
	height:300px;width:500px;display:block;
}
.ratingImgCl{
	height:70px;width:70px;
}
.ratingStarDivCl{
	height:70px;width:70px;float:left;
}
#ratingStarDiv1{
	padding-left:70px;width:140px;
}
#rateContentDiv{
	display:none;
}
#noRatingDiv{
	height:20px;width:100%;
}
#ratingComment{
	width :80%;
}
#rateNowBtn{
	width:80%;
	background-color:lightblue;
	color:blue;
}
</style>

<?php

//rating is done here
	if(isset($_POST['rateNowBtn'])){
		if($_POST['ratingStarCount'] != ''){
			$doRatingQry='insert into ratingtbl (bookId, rating, comment, dateTime) values ('. $_POST['bookIdRating'] .', '. $_POST['ratingStarCount'] .', "'. $_POST['ratingComment'] .'", "'.  date('Y-m-j') .'");';
			if(mysqli_query($connect, $doRatingQry)){
				echo '<script>window.reload();</script>';
			}else{
				echo '<script>alert("rating is not successfull");</script>';
			}
		}
	}

	//checks if something to rate

	$ratingQuestionPara=''; $bookIdRating='';
	$getBookingForRateQry='select * from booktbl where clId='.$_SESSION['userClId'] .' and dateTime <  "'. date('Y-m-j') .'"';
	$getBookingForRateRslt=mysqli_query($connect, $getBookingForRateQry);
	while($getBookingForRateRow=mysqli_fetch_array($getBookingForRateRslt)){
		$checkAlreadyRated='select id from ratingtbl where bookId='. $getBookingForRateRow['id'];
		if(!(mysqli_num_rows(mysqli_query($connect, $checkAlreadyRated)))){
			$ratingQuestionPara='Would you like to RATE for the journy from <b> '. $getBookingForRateRow['fromLoc'] .' </b> to <b>'. $getBookingForRateRow['toLoc'] .'</b> on '. $getBookingForRateRow['dateTime'] .'?';
			$bookIdRating= $getBookingForRateRow['id'];
			break;
		}
	}
?>
<form action='<?php $_PHP_SELF ?>' method='post'>
<div class="content-wrapper">
    <!-- Content Header (Page header) -->
		<div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Bordered Table</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tr>
                  <!--<th style="width: 10px">#</th>-->
                  <th style="width: 15%">Driver Name</th>
                  <th style="width: 25%">From location</th>
                  <th style="width: 25%">To location</th>
				  <th style="width: 30px">Distance</th>
				  <th style="width: 30px">Amount</th>
				  <th style="width: 30px">Status </th>
                </tr>
				<?php
					//echo '<script>alert("'.  $_SESSION['userClId'] .'");</script>';
					$getDrivesQry='select * from booktbl where clId='. $_SESSION['userClId'];
					$getDrivesRslt=mysqli_query($connect, $getDrivesQry);
					if(mysqli_num_rows($getDrivesRslt)){
						while ($getDrivesRow=mysqli_fetch_array($getDrivesRslt)){
							$getDriverName='select name from drivertbl where id ='. $getDrivesRow['drId'];
							if($getDrivesRow['dateTime'] <  date('Y-m-j')){
								if($getDrivesRow['status']==1){
									$status= 'pending';
								}else if($getDrivesRow['status']==2){
									$status='completed';
								}else if($getDrivesRow['status']==3){
									$status='canceled';
								}else{
									$status='error';
								}
							}else{
								$status= 'booked';
							}
							echo '<tr>
									<td>'. mysqli_fetch_array(mysqli_query($connect, $getDriverName))['name'] .'</td>
									<td>
										'. $getDrivesRow['fromLoc'] .'
									</td>
									
									<td>
									'. $getDrivesRow['toLoc'] .'
									</td>
									<td>'. $getDrivesRow['distance'] .'</td>
									<td>'. $getDrivesRow['amount'] .'</td>
									<td>'. $status .'</td>
								</tr>';
						}
					}else{
						echo '<tr><td></td><td></td><td >you have no drives yet</td><td></td><td></td><td></td></tr>';
					}
				?>
                
              </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">&laquo;</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">&raquo;</a></li>
              </ul>
            </div>
          </div>
		  <center>
			  <div id='rateDiv'>
				  <div id='rateContentDiv'>
					<p id='ratingQuestionPara'><?php echo $ratingQuestionPara; ?> </p>
					<div style='height:100px;width:100%;'>
						<div id='ratingStarDiv1' class='ratingStarDivCl'><img src='images/emptyRateing.png' id='emptyRatingImg1' class='ratingImgCl'></img></div>
						<div id='ratingStarDiv2' class='ratingStarDivCl'><img src='images/emptyRateing.png' id='emptyRatingImg2' class='ratingImgCl'></img></div>
						<div id='ratingStarDiv3' class='ratingStarDivCl'><img src='images/emptyRateing.png' id='emptyRatingImg3' class='ratingImgCl'></img></div>
						<div id='ratingStarDiv4' class='ratingStarDivCl'><img src='images/emptyRateing.png' id='emptyRatingImg4' class='ratingImgCl'></img></div>
						<div id='ratingStarDiv5' class='ratingStarDivCl'><img src='images/emptyRateing.png' id='emptyRatingImg5' class='ratingImgCl'></img></div>
					</div>
					<textarea id='ratingComment' name='ratingComment' placeholder='please comment here against your rating' rows='5'  ></textarea>
					<input type='hidden' id='bookIdRating' name='bookIdRating' value='<?php echo $bookIdRating ?>' />
					<input type='hidden' id='ratingStarCount' name='ratingStarCount' />
					<button id='rateNowBtn' name='rateNowBtn'>Rate now</button>
					<div id='noRatingDiv'><p>I dont want to rate</p></div>
				  </div>
			  </div>
		  </center>
  </div>
 </form>


<script>
	$(document).ready(function(){
		if($('#bookIdRating').val()!=''){
			$('#rateDiv').animate({
				height:'300px',
				width:'500px'
			});
			$('#rateContentDiv').css('display', 'block');
		}
		$('.ratingImgCl').click(function (){
			var thisRatingImg = $(this);
			var changeRateStar=1;
			var ratingStarCount=0;
			$('.ratingImgCl').each(function(){
				if(changeRateStar==1){
					var parentDiv=$(this).parent();
					$(this).remove();
					parentDiv.append('<img src="images/ratedRate.jpg" class="ratingImgCl"></img>');
					ratingStarCount++;
					if($(this).attr('id') == thisRatingImg.attr('id')){
						changeRateStar=0;
					}
				}				
			});
			$('#ratingStarCount').val(ratingStarCount);
		});

		$('#noRatingDiv').hover(function(){
			$('#noRatingDiv').css('color', 'red');
		});

		$('#noRatingDiv').mouseout(function(){
			$('#noRatingDiv').css('color', 'black');
		});

		$('#noRatingDiv').click(function(){
			$('#rateContentDiv').css('display', 'none');
			$('#rateDiv').animate({
				height:'0px',
				width:'0px'
			});
		});
	});
</script>

<?php
	include('footer.php');
?>