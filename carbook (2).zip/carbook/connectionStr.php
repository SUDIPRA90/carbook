<?php
$connect = new mysqli('localhost:3306', 'root', '', 'bookCar');
?>