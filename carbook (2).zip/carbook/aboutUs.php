<?php
include('header.php');
?>

<div class="content-wrapper">

</div>

<?php
include('footer.php');
?>
