<?php
include('header.php');
?>

<div class="content-wrapper">
    <!-- Content Header (Page header) -->
		<div class="box">
            <div class="box-header with-border">
              <h3 class="box-title">Bordered Table</h3>
            </div>
            <!-- /.box-header -->
            <div class="box-body">
              <table class="table table-bordered">
                <tr>
                  <!--<th style="width: 10px">#</th>-->
                  <th style="width: 25%">Driver Name</th>
                  <th style="width: 25%">From location</th>
                  <th style="width: 10%">To location</th>
				  <th style="width: 50px">Distance</th>
				  <th style="width: 50px">Amount</th>
				  <th style="width: 50px">Paid </th>
                </tr>
				<?php
					$getDrivesQry='select * from drivestbl where drId='. $_SESSION['userDrId'];
					$getDrivesRslt=mysqli_query($connect, $getDrivesQry);
					if(mysqli_num_rows($getDrivesRslt)){
						while ($getDrivesRow=mysqli_fetch_array($getDrivesRslt)){
							$getDriverName='select name from clienttbl where id ='. $getDrivesRow['clId'];
							
							if(getDrivesRow['status']==1){$status= 'pending';}else{$status='completed';}
							echo '<tr>
									<td>'. mysqli_fetch_array(mysqli_query($getDriverName))['name'] .'</td>
									<td>
										'. $getDrivesRow['fromLoc'] .'
									</td>
									<td>Update software</td>
									<td>
									'. $getDrivesRow['toLoc'] .'
									</td>
									<td>'. $getDrivesRow['distance'] .'</td>
									<td>'. $getDrivesRow['amount'] .'</td>
									<td>'. $status .'</td>
								</tr>';
						}
					}else{
						echo '<tr><td></td><td></td><td >you have no payments yet</td><td></td><td></td><td></td></tr>';
					}
				?>
                
              </table>
            </div>
            <!-- /.box-body -->
            <div class="box-footer clearfix">
              <ul class="pagination pagination-sm no-margin pull-right">
                <li><a href="#">&laquo;</a></li>
                <li><a href="#">1</a></li>
                <li><a href="#">2</a></li>
                <li><a href="#">3</a></li>
                <li><a href="#">&raquo;</a></li>
              </ul>
            </div>
          </div>
  </div>
  
  <?php
include('footer.php');
  ?>