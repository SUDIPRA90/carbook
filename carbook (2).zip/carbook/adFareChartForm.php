<?php
	include('adHeader.php');
?>

<?php
$hiddenFareId='';
$meter='';
$rate='';
if(isset($_SESSION['fareId'])){
	$hiddenFareId=$_SESSION['fareId'];
	unset($_SESSION['fareId']);
	$getFareDtlsQry='select * from faretbl where id='. $hiddenFareId;
	$getFareDtlsRow=mysqli_fetch_array(mysqli_query($connect, $getFareDtlsQry));
	$meter=$getFareDtlsRow['meter'];
	$rate=$getFareDtlsRow['rate'];
}

if(isset($_POST['addFareBtn'])){
	if($_POST['hiddenFareId']==''){
		$addFareQry='insert into faretbl ( meter, rate) values('. $_POST['meter'] .', '. $_POST['rate'] .')';
		if(mysqli_query($connect, $addFareQry)){
			echo '<script>alert("successfully added");</script>';
		}else{
			echo '<script>alert("error while adding");</script>';
		}
	}else{
		$updateFareQry='update faretbl set meter = '. $_POST['meter'] .', rate = '. $_POST['rate'] .' where id = '. $_POST['hiddenFareId'];
		if(mysqli_query($connect, $updateFareQry)){
			echo '<script>alert("successfully updated");</script>';
		}else{
			echo '<script>alert("error while updating");</script>';
		}
	}
}

?>
<div class="content-wrapper">
<div class="box box-info">
            <div class="box-header with-border">
              <h3 class="box-title">Horizontal Form</h3>
            </div>
            <!-- /.box-header -->
            <!-- form start -->
            <form action='<?php $_PHP_SELF ?>' method='post'  enctype='multipart/form-data'>
			<input type='hidden' name='hiddenFareId' id='hiddenFareId' value='<?php echo $hiddenFareId ?>' />
              <div class="box-body">
                <div class="form-group">
                  <label for="inputEmail3" class="col-sm-2 control-label">Distance</label>

                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="meter" name='meter' value='<?php echo $meter ?>' placeholder="Distance in meter">
                  </div>
                </div>
                <div class="form-group">
                  <label for="inputPassword3" class="col-sm-2 control-label">Fare</label>

                  <div class="col-sm-10">
                    <input type="text" class="form-control" id="rate" name="rate" value='<?php echo $rate ?>' placeholder="fare in rupee">
                  </div>
                </div>
              <!--  <div class="form-group">
                  <div class="col-sm-offset-2 col-sm-10">
                    <div class="checkbox">
                      <label>
                        <input type="checkbox"> Remember me
                      </label>
                    </div>
                  </div>
                </div>-->
              </div>
              <!-- /.box-body -->
              <div class="box-footer">
                <button type="submit" class="btn btn-default">Cancel</button>
                <button type="submit" id='addFareBtn' name='addFareBtn' class="btn btn-info pull-right">Submit</button>
              </div>
              <!-- /.box-footer -->
            </form>
          </div>
		  </div>
		  
<?php
	include('footer.php');
?>
