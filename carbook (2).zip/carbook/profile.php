<html>
<body>
<?php
session_start();	
if(isset($_SESSION['userClId'])){
	echo '<script>window.location.href="clProfile.php";</script>';
}
else if(isset($_SESSION['userDrId'])){
	echo '<script>window.location.href="drProfile.php";</script>';
}else{
	echo '<script>window.location.href="index.php";</script>';
}
?>
</body>
</html>