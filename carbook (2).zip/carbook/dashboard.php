<?php
session_start();
if(isset($_SESSION['userClId'])){
	echo '<script>window.location.href="clDashboard.php";</script>';
}
else if(isset($_SESSION['userClId'])){
	echo '<script>window.location.href="drDashboard.php";</script>';
}else{
	echo '<script>window.location.href="index.php";</script>';
}
?>