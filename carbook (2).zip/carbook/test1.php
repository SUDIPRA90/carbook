<html>

<body>
<?php
	if(isset($_POST["submit"])){
		$fileName=$_FILES['file']['name'];
		$fileTempName=$_FILES['file']['tmp_name'];
		$fileStore='profilePic/driver/'. $fileName;
		if(move_uploaded_file($fileTempName, $fileStore))
		{
			echo '<script>alert("successfully signed up");</script>';
		}else{
			echo '<script>alert("error");</script>';
		}
	}

?>
<form action='test1.php' method='post' enctype='multipart/form-data'>
<input type='file' name='file' />
<input type='submit' name='submit' text='click' />
</form>
</body>
</html>