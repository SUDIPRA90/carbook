<?php
session_start();
if(isset($_SESSION['userClId'])){
	echo '<script>window.location.href="clMyDrives.php";</script>';
}
else if(isset($_SESSION['userDrId'])){
	echo '<script>window.location.href="drMyDrives.php";</script>';
}else{
	echo '<script>window.location.href="index.php";</script>';
}
?>
